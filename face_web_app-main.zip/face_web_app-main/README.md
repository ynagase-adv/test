# face_web_app

画像認識機能として以下をWebアプリケーションから操作出来ます。
　・顔・名前学習
　・感情分析
[顔・名前学習]に関しては、画像認識モデルアプリケーション(face_model_app)のAPIを呼び出す事で実現しています。


# 環境準備

## 事前準備

- git、Docker、docker-compose はインストール済みの認識です。

## 任意のディレクトリにcd。本例では、[/home/user1/dev/]下を想定しています。

```
cd /home/user1/dev/
```


## ソースコードをGitHubよりダウンロードする

- 2021/3/28時点では、ブランチ[yutnagase/api]からダウンロードします。

```
git clone -b yutnagase/api https://github.com/ynagase-adv/face_web_app.git
```

- mainマージ後は、以下からダウンロードします。

```
git clone https://github.com/ynagase-adv/face_web_app.git
```

## プログラムディレクトリ下に移動します。

```
cd face_web_app/
```

## プログラムの手直し①
- 【課題】URLのIPアドレスハードコーディングしている個所が有ります。
- ホストのIPアドレスで修正する必要が有ります。
- 以下のファイルを開きます。

```
vi static/facelogin/js/predict.js 
```

- 28行目のIPアドレスをホストのIPアドレスに変更してください。

## プログラムの手直し②
- 【課題】URLのIPアドレスハードコーディングしている個所が有ります。
- ホストのIPアドレスで修正する必要が有ります。
- 以下のファイルを開きます。

```
vi facelogin/views.py
```

- 60行目と112行目のIPアドレスをホストのIPアドレスに変更してください。

## Dockerコンテナが参照しているDBボリュームを作成

```
docker volume create --name=face_web_db_data
```

# 起動方法
## 注意点
本Webアプリケーションを起動前に画像認識モデルアプリケーション(face_model_app)のAPIサーバーを起動しておいてください。

## Dockerコンテナを起動します。

```
docker-compose up
```

## ブラウザで以下URLを入力し、アクセスします。

```
https://(DockerホストのIPアドレス):8000
```

例：Dockerホストが[192.168.0.86]の場合、以下URLとなります。

```
https://192.168.0.86:8000となります。
```

# 停止方法
## Dockerコンテナを起動します。

```
docker-compose down
```
