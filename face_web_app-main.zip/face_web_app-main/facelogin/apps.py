from django.apps import AppConfig


class FaceloginConfig(AppConfig):
    name = 'facelogin'
