from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from . forms import UserForm
from django.conf import settings
from django.contrib import messages
from django.views.generic import TemplateView
from typing import Optional

import base64
import os
import datetime
import secrets

import requests


class WkFace():

    base64pic: str
    name: Optional[str] = None


class LoginView(TemplateView):
    def __init__(self):
        self.params = {}
        self.template_name = 'facelogin/login.html'

    def get(self, request):
        self.params['form'] = UserForm()
        return render(request, self.template_name, self.params)

    def post(self, request):

        req_faces = request.POST.getlist("faces")
        faces = []

        if (req_faces is not None):

            # 出力先ディレクトリ名を取得する
            out_dir = os.path.join(
                settings.FACE_RECOGNITION_DIR,
                datetime.date.today().strftime("%Y%m%d"),
                secrets.token_hex(16))

            if not os.path.exists(out_dir):
                # ディレクトリが存在しない場合、ディレクトリを作成する
                # ※ハッシュ値を付与しているので、基本は無いはずである。
                # ※よって、既にディレクトリが有った場合の考慮は除外する
                os.makedirs(out_dir)

            for face in req_faces:
                base64pic = face.replace('data:image/jpeg;base64,', '')
                pic_decode = base64.b64decode(base64pic)
                pic_filename = "upload_data%s.jpeg" % secrets.token_hex(16)

                with open(out_dir + "/" + pic_filename, 'bw') as f4:
                    f4.write(pic_decode)
                faces.append(base64pic)

            url = "http://" + settings.LOCAL_IP_ADDRESS + ":8888/faces/"
            data = {'faces': faces}

            r = requests.post(url, json=data)

            if r.status_code == requests.codes.ok:
                messages.success(
                    request,
                    "{}さん　認証に成功しました。".format(r.json()['name']))
            else:
                messages.error(
                    request,
                    '認証に失敗しました。')

        return redirect(reverse_lazy('base:top'))


class ShootView(TemplateView):
    def __init__(self):
        self.params = {}
        self.template_name = 'facelogin/shoot.html'

    def get(self, request):
        self.params['form'] = UserForm()
        return render(request, self.template_name, self.params)

    def post(self, request):

        faces = request.POST.getlist("faces")
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')

        if (faces is not None):

            # 出力先ディレクトリ名を取得する
            out_dir = os.path.join(
                settings.FACE_RECOGNITION_DIR,
                datetime.date.today().strftime("%Y%m%d"),
                secrets.token_hex(16))

            if not os.path.exists(out_dir):
                # ディレクトリが存在しない場合、ディレクトリを作成する
                # ※ハッシュ値を付与しているので、基本は無いはずである。
                # ※よって、既にディレクトリが有った場合の考慮は除外する
                os.makedirs(out_dir)

            base64pics = []

            for face in faces:
                base64pic = face.replace('data:image/jpeg;base64,', '')
                base64pics.append(base64pic)

            url = "http://" + settings.LOCAL_IP_ADDRESS + ":8888/shoot/"
            data = {'fname': fname, 'lname': lname, 'faces': base64pics}

            r = requests.post(url, json=data)
            if r.status_code == requests.codes.ok:
                messages.success(request, '顔の学習を開始しました。数分で学習が終了致します。')
            else:
                messages.error(request, '顔の学習に失敗しました。管理者にご確認ください。')

        return redirect(reverse_lazy('base:top'))


class EmotionView(TemplateView):
    def __init__(self):
        self.params = {}
        self.template_name = 'facelogin/emotion.html'

    def get(self, request):
        self.params['form'] = UserForm()
        return render(request, self.template_name, self.params)
