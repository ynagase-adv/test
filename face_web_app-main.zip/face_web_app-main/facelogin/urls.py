from django.urls import path
from . import views

app_name = 'facelogin'

urlpatterns = [
    path('login/', views.LoginView.as_view(), name='login'),
    path('shoot/', views.ShootView.as_view(), name='shoot'),
    path('emotion/', views.EmotionView.as_view(), name='emotion'),
]
