from django.forms import ModelForm
from django import forms


class UserForm(forms.Form):
    faces = forms.CharField(
        label='',
        widget=forms.Textarea(
            attrs={
                "rows": 20,
                "cols": 10,
            }
        )
    )
