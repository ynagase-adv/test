new Vue({
    el: '#app',
    data: {
      video: {},
      canvas: {},
      faces: [],
      capture_cnt: 0,
      capture_maxcnt: 5,
      interval: 1200,
      processing: true,
    },
    mounted() {
      this.video = this.$refs.video
      this.init()
    },
    methods: {
      init() {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          navigator.mediaDevices.getUserMedia({
            video: true
          }).then(stream => {
            this.processing = true
            this.video.srcObject = stream
            this.video.play()
            this.capture()
          })
        }
      },
      capture_main() {
        this.canvas = this.$refs.canvas
        canv_width = document.getElementById("video").videoWidth
        canv_height = document.getElementById("video").videoHeight
        this.canvas.getContext('2d').drawImage(this.video, 0, 0, canv_width, canv_height)
        this.faces.push(this.canvas.toDataURL("image/jpeg"))
        this.capture_cnt++
      },
      capture() {
        this.capture_cnt = 0
        var timerId = setInterval(function () {
          this.capture_main()
          if (this.capture_cnt >= this.capture_maxcnt) {
            clearInterval(timerId)
            this.processing = false
          }
        }.bind(this), this.interval)
      },
      isProcessing: function () {
        return this.processing
      }
    }
  });